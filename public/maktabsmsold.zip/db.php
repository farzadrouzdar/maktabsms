<?php
// تنظیم منطقه زمانی
date_default_timezone_set('Asia/Tehran');

$host = 'localhost';
$dbname = 'maktabsms';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// تنظیمات پیامک
$sms_first_part_chars = 70;
$sms_next_part_chars = 67;
$sms_max_parts = 8;
$sms_cost = 100; // تومان برای هر پارت
$sms_footer_text = 'لغو11';
$sabanovin_api_key = 'sa2888726250:ocVL0dpy1VAYj1KF203EEDTP2E73QG6tuJCt'; // جای YOUR-API-KEY کلید API خودت رو بذار
$sabanovin_gateway = '50003000201'; // شماره خط خودت رو بذار
?>