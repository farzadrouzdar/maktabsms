<?php
include 'header.php';

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}
?>

<div class="max-w-md mx-auto bg-white p-6 rounded-lg shadow-lg">
    <h2 class="text-2xl font-bold mb-6 text-center">ثبت‌نام مدرسه</h2>
    <form action="save_register.php" method="POST">
        <div class="mb-4">
            <label for="mobile" class="block text-gray-700 font-medium mb-2">شماره موبایل مدیر</label>
            <input type="text" id="mobile" name="mobile" class="w-full p-2 border rounded" required pattern="09[0-9]{9}" placeholder="مثال: 09123456789">
        </div>
        <div class="mb-4">
            <label for="name" class="block text-gray-700 font-medium mb-2">نام مدرسه</label>
            <input type="text" id="name" name="name" class="w-full p-2 border rounded" required placeholder="مثال: مدرسه نمونه">
        </div>
        <div class="mb-4">
            <label for="type" class="block text-gray-700 font-medium mb-2">نوع مدرسه</label>
            <select id="type" name="type" class="w-full p-2 border rounded" required>
                <option value="" disabled selected>انتخاب کنید</option>
                <option value="دبستان">دبستان</option>
                <option value="راهنمایی">راهنمایی</option>
                <option value="دبیرستان">دبیرستان</option>
                <option value="هنرستان">هنرستان</option>
            </select>
        </div>
        <button type="submit" class="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600">ثبت‌نام</button>
    </form>
</div>
</div>
</body>
</html>