<?php
include 'header.php';

// چک کردن ورود کاربر و نقش
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'school_admin') {
    $_SESSION['error'] = "دسترسی غیرمجاز.";
    header("Location: dashboard.php");
    exit;
}

include 'template.php';

// دریافت اطلاعات مدرسه
$stmt = $pdo->prepare("SELECT * FROM schools WHERE id = ?");
$stmt->execute([$_SESSION['school_id']]);
$school = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $type = trim($_POST['type']);

    if (empty($name) || empty($type)) {
        $_SESSION['error'] = "نام و نوع مدرسه نمی‌توانند خالی باشند.";
        header("Location: settings.php");
        exit;
    }

    // به‌روزرسانی مدرسه
    $stmt = $pdo->prepare("UPDATE schools SET name = ?, type = ? WHERE id = ?");
    $stmt->execute([$name, $type, $_SESSION['school_id']]);

    $_SESSION['message'] = "تنظیمات با موفقیت ذخیره شد.";
    header("Location: settings.php");
    exit;
}
?>

<div class="max-w-md mx-auto bg-white p-6 rounded-lg shadow-lg">
    <h2 class="text-2xl font-bold mb-6 text-center">تنظیمات مدرسه</h2>
    <form action="settings.php" method="POST">
        <div class="mb-4">
            <label class="block text-gray-700 font-medium mb-2">نام مدرسه</label>
            <input type="text" name="name" class="w-full p-2 border rounded" required value="<?php echo htmlspecialchars($school['name']); ?>">
        </div>
        <div class="mb-4">
            <label class="block text-gray-700 font-medium mb-2">نوع مدرسه</label>
            <input type="text" name="type" class="w-full p-2 border rounded" required value="<?php echo htmlspecialchars($school['type']); ?>">
        </div>
        <button type="submit" class="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600">ذخیره</button>
    </form>
</div>
</div>
</body>
</html>