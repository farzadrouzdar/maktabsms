<?php
include 'header.php';

// چک کردن ورود کاربر
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "لطفاً ابتدا وارد شوید.";
    header("Location: login.php");
    exit;
}

// دریافت اطلاعات مدرسه
$stmt = $pdo->prepare("SELECT * FROM schools WHERE id = ?");
$stmt->execute([$_SESSION['school_id']]);
$school = $stmt->fetch(PDO::FETCH_ASSOC);
$header_text = $school['type'] . ' ' . $school['name'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $mobile = $_POST['mobile'];
    $message = isset($_POST['message']) ? trim($_POST['message']) : '';
    $message = preg_replace('/[\u200B-\u200D\uFEFF\s\r\n]+/', ' ', $message);
    $message = trim($message);
    $scheduled_at = $_POST['scheduled_at'] ?? null;

    file_put_contents('sms_validation_log.txt', "Input Message: " . json_encode($message) . "\n", FILE_APPEND);

    $errors = [];
    if (!preg_match('/^09[0-9]{9}$/', $mobile)) {
        $errors[] = "شماره موبایل نامعتبر است.";
    }
    if (empty($message)) {
        $errors[] = "متن پیامک نمی‌تواند خالی باشد.";
        file_put_contents('sms_validation_log.txt', "Empty Message Detected\n", FILE_APPEND);
    } elseif (!preg_match('/^[\u0600-\u06FF]|^[\s]*[\u0600-\u06FF]/', $message)) {
        $errors[] = "متن پیامک باید با کاراکتر فارسی شروع شود.";
        file_put_contents('sms_validation_log.txt', "Invalid Persian Start: " . json_encode($message) . "\n", FILE_APPEND);
    }
    if ($scheduled_at && strtotime($scheduled_at) < time()) {
        $errors[] = "زمان ارسال نمی‌تواند در گذشته باشد.";
    }

    $header_len = mb_strlen($header_text, 'UTF-8');
    $footer_len = mb_strlen($sms_footer_text, 'UTF-8');
    $message_len = mb_strlen($message, 'UTF-8');
    $total_len = $header_len + $message_len + $footer_len + 4;
    $parts = 1;
    if ($total_len > $sms_first_part_chars) {
        $extra_chars = $total_len - $sms_first_part_chars;
        $parts = 1 + ceil($extra_chars / $sms_next_part_chars);
    }
    if ($parts > $sms_max_parts) {
        $errors[] = "پیامک بیش از حد مجاز ($sms_max_parts پارت) است.";
    }
    $total_cost = $parts * $sms_cost;

    $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $balance = $stmt->fetchColumn();
    if ($balance < $total_cost) {
        $errors[] = "اعتبار کافی نیست. لطفاً حساب خود را شارژ کنید.";
    }

    if (empty($errors)) {
        $full_message = $header_text . "\n\n" . $message . "\n\n" . $sms_footer_text;

        if ($scheduled_at) {
            $stmt = $pdo->prepare("
                INSERT INTO scheduled_sms (user_id, mobile, message, scheduled_at, status, created_at)
                VALUES (?, ?, ?, ?, 'PENDING', NOW())
            ");
            $stmt->execute([$_SESSION['user_id'], $mobile, $full_message, $scheduled_at]);

            $stmt = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
            $stmt->execute([$total_cost, $_SESSION['user_id']]);

            $_SESSION['message'] = "پیامک برای ارسال در زمان مشخص ذخیره شد.";
            header("Location: send_sms.php");
            exit;
        } else {
            $url = "https://api.sabanovin.com/v1/{$sabanovin_api_key}/sms/send.json";
            $data = [
                'gateway' => $sabanovin_gateway,
                'to' => $mobile,
                'text' => $full_message
            ];

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curl_error = curl_error($ch);
            curl_close($ch);

            file_put_contents('sabanovin_log.txt', "Send SMS - HTTP Code: $http_code\nResponse: $response\nError: $curl_error\nText: $full_message\n\n", FILE_APPEND);

            $result = json_decode($response, true);
            if ($http_code == 200 && isset($result['status']['code']) && $result['status']['code'] == 200) {
                $stmt = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
                $stmt->execute([$total_cost, $_SESSION['user_id']]);

                $batch_id = $result['batch_id'] ?? null;
                $reference_id = $result['entries'][0]['reference_id'] ?? null;
                $stmt = $pdo->prepare("
                    INSERT INTO sms_logs (user_id, mobile, message, status, batch_id, reference_id, cost, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                ");
                $stmt->execute([
                    $_SESSION['user_id'], $mobile, $full_message, 'ENQUEUED', $batch_id, $reference_id, $total_cost
                ]);

                $_SESSION['message'] = "پیامک با موفقیت ارسال شد.";
                header("Location: send_sms.php");
                exit;
            } else {
                $error_message = isset($result['status']['message']) ? $result['status']['message'] : 'خطا در ارسال پیامک';
                $_SESSION['error'] = $error_message;
                header("Location: send_sms.php");
                exit;
            }
        }
    } else {
        $_SESSION['error'] = implode(', ', $errors);
        header("Location: send_sms.php");
        exit;
    }
}
?>