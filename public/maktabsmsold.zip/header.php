<?php
include 'header.php';

// چک کردن ورود کاربر
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}
?>

<div class="max-w-md mx-auto bg-white p-6 rounded-lg shadow-lg">
    <h2 class="text-2xl font-bold mb-6 text-center">ورود به سیستم</h2>
    <form action="send_otp.php" method="POST">
        <div class="mb-4">
            <label class="block text-gray-700 font-medium mb-2">شماره موبایل</label>
            <input type="text" name="mobile" class="w-full p-2 border rounded" required pattern="09[0-9]{9}" placeholder="مثال: 09123456789">
        </div>
        <button type="submit" class="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600">ارسال کد OTP</button>
    </form>
</div>
</div>
</body>
</html>